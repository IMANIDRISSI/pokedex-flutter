package com.example.uf3_p1_futter_cloud_firestore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

import 'package:flutter/material.dart';
import 'pokedex.dart';

void main() {
  runApp(const PokedexApp());
}

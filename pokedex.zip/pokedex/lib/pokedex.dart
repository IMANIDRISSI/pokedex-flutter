import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PokedexApp extends StatefulWidget {
  const PokedexApp({Key? key}) : super(key: key);

  @override
  _PokedexAppState createState() => _PokedexAppState();
}

class _PokedexAppState extends State<PokedexApp> {
  List<dynamic> _allPokemon = [];
  List<dynamic> _filteredPokemon = [];
  bool _loading = true;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadPokemonData();
  }

  Future<void> _loadPokemonData() async {
    setState(() {
      _loading = true;
    });

    try {
      final response = await http.get(
          Uri.parse('https://pokeapi.co/api/v2/pokemon?limit=50'));
      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        List<dynamic> fetchedPokemon = decodedData['results'];

        // Obtiene detalles adicionales de cada Pokémon.
        for (var pokemon in fetchedPokemon) {
          final detailsResponse =
          await http.get(Uri.parse(pokemon['url']));
          if (detailsResponse.statusCode == 200) {
            final details = json.decode(detailsResponse.body);
            pokemon['image'] = details['sprites']['front_default'];
            pokemon['type'] = details['types'][0]['type']['name'];
          }
        }

        setState(() {
          _allPokemon = fetchedPokemon;
          _filteredPokemon = List.from(fetchedPokemon);
          _loading = false;
        });
      }
    } catch (error) {
      // Manejo básico de errores.
      setState(() {
        _loading = false;
      });
    }
  }

  void _updateFilter(String query) {
    final lowerQuery = query.toLowerCase();
    setState(() {
      _filteredPokemon = _allPokemon.where((pokemon) {
        final name = pokemon['name'].toString().toLowerCase();
        final type = pokemon['type'].toString().toLowerCase();
        return name.contains(lowerQuery) || type.contains(lowerQuery);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFFFFC0CB), // Pastel rosado
        scaffoldBackgroundColor: const Color(0xFFF5F5DC), // Beige
        appBarTheme: const AppBarTheme(
          color: Color(0xFFFFC0CB), // AppBar en tono pastel rosado
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFFC0CB), // Usamos backgroundColor
          ),
        ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Pokedex App',
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
          centerTitle: true,
        ),
        body: Column(
          children: [
            // Campo de búsqueda
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _searchController,
                onChanged: _updateFilter,
                decoration: InputDecoration(
                  hintText: "Buscar por nombre o tipo...",
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xFFFFC0CB)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xFFFFC0CB)),
                  ),
                ),
              ),
            ),
            // Contenido principal con RefreshIndicator.
            Expanded(
              child: RefreshIndicator(
                onRefresh: _loadPokemonData,
                child: _loading
                    ? const Center(child: CircularProgressIndicator())
                    : GridView.builder(
                  padding: const EdgeInsets.all(8.0),
                  physics:
                  const AlwaysScrollableScrollPhysics(),
                  gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: _filteredPokemon.length,
                  itemBuilder: (context, index) {
                    final pokemon = _filteredPokemon[index];
                    return Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      color:
                      const Color(0xFFFFF0F5), // Fondo pastel rosado
                      child: Column(
                        mainAxisAlignment:
                        MainAxisAlignment.center,
                        children: [
                          Image.network(
                            pokemon['image'] ?? '',
                            height: 80,
                            fit: BoxFit.contain,
                          ),
                          const SizedBox(height: 10),
                          Text(
                            pokemon['name']
                                .toString()
                                .toUpperCase(),
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Tipo: ${pokemon['type']}',
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
            // Botón de recarga al final de la pantalla.
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                onPressed: _loadPokemonData,
                child: const Text("Recargar"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
